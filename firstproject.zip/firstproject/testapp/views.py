from django.shortcuts import render
from django.http import HttpResponse
from testapp.models import Employee
# Create your views here.
def employee_info_view(request):
    employees=Employee.objects.all()
    data={'employees':employees}
    res=render(request,'testapp/employees.html',data)
    return (res)
def greeting(request):
    s="<h1>welcome first page Hello this is my site</h1>"
    return HttpResponse(s)

def showContact(request):
    s="<h1>Contacts:--</h1>"
    s+="<p>Mobile no:88002898934</p>"
    return HttpResponse(s)

def about(request):
    return render(request,'testapp/about.html')
