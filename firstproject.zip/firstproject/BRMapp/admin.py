from django.contrib import admin
from BRMapp.models import BRMuser
# Register your models here.
admin.site.register(BRMuser)
