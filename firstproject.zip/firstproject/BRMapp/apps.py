from django.apps import AppConfig


class BrmappConfig(AppConfig):
    name = 'BRMapp'
